import React from 'react';
import { TextField, Checkbox, FormControlLabel, Button, Container, Typography, Box, Grid } from '@mui/material';
import { Link } from 'react-router-dom';
import SocialIcons from '../components/SocialIcons';
import '../styles/Login.css'

const Login = () => {
  return (
    <Container>
      <Box
        display="flex"
        flexDirection="column"
        alignItems="center"
        maxWidth={400}
        mx="auto"
        p={2}
      >
        <Typography variant="h4">Login</Typography>
        <Box mt={2} width="100%">
          <TextField label="Username" fullWidth margin="normal" />
          <TextField label="Password" type="password" fullWidth margin="normal" />
        </Box>
        <Grid container alignItems="center" justifyContent="space-between" mt={1}>
          <Grid item>
            <FormControlLabel control={<Checkbox />} label="Remember Me" />
          </Grid>
          <Grid item>
            <Link to="/forgot-password" className="forgot-password">Forgot Password?</Link>
          </Grid>
        </Grid>
        <Button variant="contained" color="primary" fullWidth sx={{ mt: 2 }}>
          Sign In
        </Button>
        <Box mt={2} textAlign="center">
          <Typography variant="body2">
            Don't have an account? <Link to="/register">Sign Up</Link>
          </Typography>
        </Box>
        {/* <SocialIcons /> */}
      </Box>
    </Container>
  );
};

export default Login;
