import React from 'react';
import { TextField, MenuItem, Button, Container, Typography, Box, Grid } from '@mui/material';
import { Link } from 'react-router-dom';
import '../styles/Register.css';

const Register = () => {
  return (
    <Container>
      <Box
        display="flex"
        flexDirection="column"
        alignItems="center"
        maxWidth={600}
        mx="auto"
        p={2}
      >
        <Typography variant="h4">Register</Typography>
        <Box mt={2} width="100%">
          <TextField label="Name" fullWidth margin="normal" />
          <TextField label="Email Address" type="email" fullWidth margin="normal" />
          <Grid container spacing={2} mt={2}>
            <Grid item xs={6}>
              <TextField
                label="Date of Birth"
                type="date"
                fullWidth
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField select label="Gender" fullWidth>
                <MenuItem value="male">Male</MenuItem>
                <MenuItem value="female">Female</MenuItem>
                <MenuItem value="other">Other</MenuItem>
              </TextField>
            </Grid>
          </Grid>
          <TextField label="Phone Number" fullWidth margin="normal" />
          <TextField label="Password" type="password" fullWidth margin="normal" />
        </Box>
        <Button variant="contained" color="primary" fullWidth sx={{ mt: 2 }}>
          Sign Up
        </Button>
        <Box mt={2} textAlign="center">
          <Typography variant="body2">
            Already have an account? <Link to="/">Login</Link>
          </Typography>
        </Box>
      </Box>
    </Container>
  );
};

export default Register;
