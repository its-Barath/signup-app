import React from 'react';
import { IconButton } from '@mui/material';
import GitHubIcon from '@mui/icons-material/GitHub';
import GoogleIcon from '@mui/icons-material/Google';
import FacebookIcon from '@mui/icons-material/Facebook';
import { Box } from '@mui/material';

const SocialIcons = () => {
  return (
    <Box display="flex" gap={2} justifyContent="center" mt={2}>
      <IconButton>
        <GitHubIcon />
      </IconButton>
      <IconButton>
        <GoogleIcon />
      </IconButton>
      <IconButton>
        <FacebookIcon />
      </IconButton>
    </Box>
  );
};

export default SocialIcons;
